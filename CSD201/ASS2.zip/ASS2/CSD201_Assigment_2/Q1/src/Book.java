class Book
 {String name;
  int price;
  Book(String xName, int xPrice)
   {name=xName;price=xPrice;
   }
  public String toString()
   {return("(" +name+","+ price + ")");
   }
 }
