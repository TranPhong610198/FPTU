package models;

import entities.Follow;

public class FollowModel extends ModelBase<Follow> {

    public FollowModel() throws Exception {
        super(Follow.class);
    }
}
