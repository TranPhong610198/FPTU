package models;

import entities.FilmCategory;

public class FilmCategoryModel extends ModelBase<FilmCategory> {

    public FilmCategoryModel() throws Exception {
        super(FilmCategory.class);
    }
}
