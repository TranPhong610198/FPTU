# PRJ301-Hanime
Project PRJ301 team 2

## Thành viên
- Triệu Quang  
- Việt Tùng  
- Vũ Thành

## Chủ đề
Web xem phim hanime dành cho wjbu FPT

## Tech
- Java Servlet, JSTL
- Bootstrap
- jQuery
- Material Design Bootstrap
- SMTP
- reCaptcha V2
- JWT (Remake base on JWT concept)
- Websocket
